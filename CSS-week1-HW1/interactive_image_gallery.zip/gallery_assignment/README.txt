# Interactive Image Gallery

Mở `index.html` bằng trình duyệt để chạy bài.

Các yêu cầu đã thực hiện:
- Có HTML, CSS và JavaScript riêng.
- Có thư mục `images/` chứa hình ảnh.
- Hàm `upDate(element)` dùng `console.log()`, cập nhật alt và source.
- Cập nhật nội dung PreviewPic và background image.
- Hàm `unDo()` đưa giao diện về trạng thái ban đầu.
- Có `window.onload` để kiểm tra sự kiện tải trang.
- Có hỗ trợ bàn phím bằng `tab`, `focus` và `blur`.
