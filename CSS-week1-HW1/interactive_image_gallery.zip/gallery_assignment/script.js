// Hàm được gọi khi người dùng di chuột hoặc focus vào một hình ảnh.
function upDate(element) {
    console.log("Sự kiện upDate đã được kích hoạt.");

    // Kiểm tra thông tin của phần tử hình ảnh.
    console.log("alt:", element.alt);
    console.log("source:", element.src);

    // Cập nhật văn bản của khung PreviewPic.
    const preview = document.getElementById("image");
    preview.innerHTML = element.alt;

    // Cập nhật hình nền bằng source của hình ảnh.
    preview.style.backgroundImage = "url('" + element.src + "')";
}

// Hàm trả khung xem trước về trạng thái ban đầu.
function unDo() {
    console.log("Đang trả khung xem trước về trạng thái ban đầu.");

    const preview = document.getElementById("image");
    preview.innerHTML = "Di chuột qua một hình ảnh bên dưới để hiển thị ở đây.";
    preview.style.backgroundImage = "none";
}

// Kiểm tra sự kiện khi trang được tải.
window.onload = function () {
    console.log("Trang web đã tải xong.");
    console.log("Interactive Image Gallery đã sẵn sàng.");
};
