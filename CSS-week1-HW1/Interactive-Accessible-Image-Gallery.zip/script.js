// Accessible interactive gallery

// Add tabindex automatically so every figure can receive keyboard focus.
function addTabIndex() {
  const figures = document.querySelectorAll("figure");

  figures.forEach(function (figure) {
    figure.setAttribute("tabindex", "0");
  });
}

// Update the visible status message when a figure is active.
function updateStatus(message) {
  const status = document.getElementById("status");

  if (status) {
    status.textContent = message;
  }
}

// React to mouse entering a figure.
function handleMouseOver(event) {
  const figure = event.currentTarget;
  const caption = figure.querySelector("figcaption");

  if (caption) {
    updateStatus("Viewing: " + caption.textContent);
  }
}

// React to mouse leaving a figure.
function handleMouseLeave() {
  updateStatus("Gallery ready.");
}

// React to keyboard focus.
function handleFocus(event) {
  const figure = event.currentTarget;
  const caption = figure.querySelector("figcaption");

  if (caption) {
    updateStatus("Focused: " + caption.textContent);
  }
}

// React when keyboard focus leaves a figure.
function handleBlur() {
  updateStatus("Gallery ready.");
}

// Set up all interactive events after the page loads.
function initializeGallery() {
  addTabIndex();

  const figures = document.querySelectorAll("figure");

  figures.forEach(function (figure) {
    figure.addEventListener("mouseover", handleMouseOver);
    figure.addEventListener("mouseleave", handleMouseLeave);
    figure.addEventListener("focus", handleFocus);
    figure.addEventListener("blur", handleBlur);
  });

  updateStatus("Gallery loaded. Use Tab to explore the images.");
}

// Page-load event.
window.addEventListener("load", initializeGallery);
