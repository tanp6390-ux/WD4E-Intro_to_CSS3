WANDER & WONDER — ORIGINAL ACCESSIBLE WEBSITE

Files:
- index.html
- places.html
- tips.html
- style.css
- images/

How to publish with GitHub Pages:
1. Create a new GitHub repository.
2. Upload all files and the images folder (do not upload only the ZIP).
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select the main branch and / (root), then Save.
6. Wait for GitHub Pages to publish the site.
7. Your site will normally be:
   https://YOUR-USERNAME.github.io/REPOSITORY-NAME/

Accessibility checklist:
- Each page has a keyboard-focusable Skip to Main Content link.
- Each main element has id="main-content".
- Navigation has an accessible label.
- Images have meaningful alt text.
- Visible focus styles are included.
- Semantic headings and landmarks are used.
